function Create(self)
	self.Frame = math.random(self.FrameCount) - 1;
end