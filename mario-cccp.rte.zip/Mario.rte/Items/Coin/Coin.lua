function Create(self)
	self.goldPerCoin = self:GetGoldValue(0, 1, 1);
	
	self.updateTimer = Timer();
	self.updateDelay = 300;	-- Time window to pickup after dropped
	
	self.animTimer = Timer();
end
function Update(self)
	self.AngularVel = self.AngularVel / 2;
	self.RotAngle = 0;
	if self.animTimer:IsPastSimMS(100) then
		self.Frame = (self.Frame < (self.FrameCount - 1)) and self.Frame + 1 or 0;
		if self.Frame == 0 then
			local glow = CreateMOPixel("Mario/Coin Glow");
			glow.Pos = self.Pos;
			MovableMan:AddParticle(glow);
		end
		self.animTimer:Reset();
	end
	local parent = self:GetParent();
	if self.FiredFrame or (self.updateTimer:IsPastSimMS(self.updateDelay) and not parent) then
		self.updateDelay = 17;	-- New update delay
		self.updateTimer:Reset();
		for actor in MovableMan.Actors do
			if (actor.ClassName == "AHuman" or actor.ClassName == "ACrab") and actor.Status < Actor.DYING then
				local dist = SceneMan:ShortestDistance(actor.Pos, self.Pos, SceneMan.SceneWrapsX);
				if dist.Magnitude < (self.Radius + actor.Radius) then
					local particleCount = 3;
					for i = 1, particleCount do
						local part = CreateMOSParticle("Mario.rte/Sparkle");
						part.Pos = self.Pos + Vector(self.Radius * (i / particleCount), 0):RadRotate(6.28 * math.random());
						part.Lifetime = part.Lifetime * RangeRand(0.5, 1.0);
						MovableMan:AddParticle(part);
					end
					ActivityMan:GetActivity():SetTeamFunds(ActivityMan:GetActivity():GetTeamFunds(actor.Team) + self:GetGoldValue(0, 1, 1), actor.Team);
					--AudioMan:PlaySound("Base.rte/Sounds/GUIs/FundsChanged".. math.random(6) ..".wav", actor.Pos);
					AudioMan:PlaySound("Mario.rte/Sounds/smb3/smb3_coin.wav", self.Pos);
					self.ToDelete = true;
				end
			end
		end
	elseif parent then
		self.updateTimer:Reset();
		self.updateDelay = 300;
	end
	if self.ToSettle then
		self.ToDelete = true;
	end
	self.ToSettle = false;
	--MovableMan.MaxDroppedItems
end