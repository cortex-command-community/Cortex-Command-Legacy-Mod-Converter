
function Update(self)

	local parent = self:GetParent();
	if parent then
		parent = ToMOSRotating(parent);
		parent.Vel = parent.Vel - SceneMan.GlobalAcc * 0.01667;
		
		if parent.ID == parent.RootID then
			self.Pos = parent.Pos;
			self.RotAngle = 0;
		end
		
		if parent.WoundCount > 0 then
			ToMOSRotating(parent):RemoveWounds(9);
			self.ToDelete = true;
		end
	else
		self.ToDelete = true;
	end
end