function Create(self)
	self.speed = 10;
	self.active = false;
	self.dir = 0;
end
function Update(self)
	if self.active then
		if self.ID == self.RootID then
		
			self.IgnoresTeamHits = false;
			self.Mass = 5 + self.Vel.Magnitude;
			self.DamageOnCollision = 1;
			
			if self.WoundCount > 0 then
				self.Vel = Vector(self.Vel.X / 2, -self.speed);
				self:GibThis();
			else
				if self.Vel.X ~= 0 then
					local x = self.Vel.X / math.abs(self.Vel.X);
					self.Vel.X = self.speed * x;
					if x ~= self.dir then
						AudioMan:PlaySound("4zK.rte/Devices/Mario/smb/smb_bump.wav ", self.Pos);
					end
					self.dir = (self.Vel.X / math.abs(self.Vel.X));
				end
				if math.abs(self.Vel.Y) > self.speed then
					self.Vel.Y = self.speed * (self.Vel.Y / math.abs(self.Vel.Y));
				end
				
				self.AngularVel = -self.dir * (self.speed * 2);
				self.RotAngle = 0;

				local terrCheck = SceneMan:GetTerrMatter(self.Pos.X, self.Pos.Y);
				if terrCheck ~= 0 then
					ToMOSRotating(self):MoveOutOfTerrain(1);
				end
			end
		else
			self.Mass = 5;
		end
	elseif self:IsActivated() then
		self.active = true;
	end
end